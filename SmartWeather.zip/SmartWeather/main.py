import tkinter as tk
from tkinter import messagebox
from urllib.request import urlopen, Request
from urllib.parse import quote
import json

APP_TITLE = "Smart Weather - آب و هوای جهان"

WEATHER_TEXT = {
    0: "صاف",
    1: "عمدتاً صاف",
    2: "نیمه ابری",
    3: "ابری",
    45: "مه",
    48: "مه یخ‌زن",
    51: "نم‌نم باران",
    53: "باران خفیف",
    55: "باران",
    56: "نم‌نم یخ‌زن",
    57: "باران یخ‌زن",
    61: "باران خفیف",
    63: "باران متوسط",
    65: "باران شدید",
    66: "باران یخ‌زن",
    67: "باران یخ‌زن شدید",
    71: "برف خفیف",
    73: "برف متوسط",
    75: "برف شدید",
    77: "دانه‌های برف",
    80: "رگبار خفیف",
    81: "رگبار متوسط",
    82: "رگبار شدید",
    85: "رگبار برف",
    86: "رگبار برف شدید",
    95: "رعد و برق",
    96: "رعد و برق با تگرگ",
    99: "رعد و برق شدید با تگرگ",
}

def get_json(url):
    req = Request(url, headers={"User-Agent": "SmartWeather/1.0"})
    with urlopen(req, timeout=15) as response:
        return json.loads(response.read().decode("utf-8"))

def search_city(name):
    url = (
        "https://geocoding-api.open-meteo.com/v1/search"
        f"?name={quote(name)}&count=10&language=fa&format=json"
    )
    data = get_json(url)
    return data.get("results", [])

def get_weather(lat, lon):
    url = (
        "https://api.open-meteo.com/v1/forecast"
        f"?latitude={lat}&longitude={lon}"
        "&current=temperature_2m,relative_humidity_2m,apparent_temperature,"
        "precipitation,weather_code,wind_speed_10m"
        "&daily=weather_code,temperature_2m_max,temperature_2m_min,"
        "precipitation_probability_max,wind_speed_10m_max,sunrise,sunset"
        "&forecast_days=7&timezone=auto"
    )
    return get_json(url)

class SmartWeather:
    def __init__(self, root):
        self.root = root
        self.root.title(APP_TITLE)
        self.root.geometry("920x700")
        self.root.minsize(820, 620)

        self.bg = "#101827"
        self.card = "#182438"
        self.text = "#f4f7fb"
        self.muted = "#aebbd0"
        self.accent = "#45b6ff"
        self.root.configure(bg=self.bg)

        title = tk.Label(
            root, text="🌤 Smart Weather",
            font=("Segoe UI", 28, "bold"),
            bg=self.bg, fg=self.text
        )
        title.pack(pady=(22, 4))

        subtitle = tk.Label(
            root, text="آب‌وهوای شهرهای سراسر جهان",
            font=("Segoe UI", 13),
            bg=self.bg, fg=self.muted
        )
        subtitle.pack()

        search_frame = tk.Frame(root, bg=self.bg)
        search_frame.pack(pady=20)

        self.city_entry = tk.Entry(
            search_frame, width=34, font=("Segoe UI", 15),
            justify="center", bg="#24334b", fg="white",
            insertbackground="white", relief="flat"
        )
        self.city_entry.pack(side="left", ipady=10, padx=8)
        self.city_entry.bind("<Return>", lambda e: self.search())

        tk.Button(
            search_frame, text="🔎 جستجوی شهر", command=self.search,
            font=("Segoe UI", 13, "bold"), bg=self.accent, fg="white",
            activebackground="#329bdc", activeforeground="white",
            relief="flat", cursor="hand2", padx=18, pady=9
        ).pack(side="left")

        self.status = tk.Label(
            root, text="نام شهر را وارد کنید؛ مثلاً تهران، London یا Tokyo",
            font=("Segoe UI", 11), bg=self.bg, fg=self.muted
        )
        self.status.pack()

        self.result_frame = tk.Frame(root, bg=self.bg)
        self.result_frame.pack(fill="both", expand=True, padx=25, pady=15)

        self.city_results = []

    def clear(self):
        for w in self.result_frame.winfo_children():
            w.destroy()

    def search(self):
        name = self.city_entry.get().strip()
        if not name:
            messagebox.showwarning("Smart Weather", "لطفاً نام یک شهر را وارد کنید.")
            return

        self.status.config(text="در حال جستجوی شهر...")
        self.root.update_idletasks()

        try:
            results = search_city(name)
        except Exception as e:
            self.status.config(text="خطا در اتصال به اینترنت")
            messagebox.showerror("خطا", f"اتصال به سرویس آب‌وهوا برقرار نشد.\n\n{e}")
            return

        self.clear()

        if not results:
            self.status.config(text="شهری با این نام پیدا نشد.")
            return

        self.status.config(text=f"{len(results)} نتیجه پیدا شد؛ یک مورد را انتخاب کنید.")

        for r in results:
            city = r.get("name", "Unknown")
            country = r.get("country", "")
            admin = r.get("admin1", "")
            label = f"{city} — {country}"
            if admin:
                label += f" ({admin})"

            b = tk.Button(
                self.result_frame, text=label,
                font=("Segoe UI", 12), anchor="e",
                bg=self.card, fg=self.text, activebackground="#263957",
                activeforeground="white", relief="flat", cursor="hand2",
                padx=15, pady=10,
                command=lambda x=r: self.show_weather(x)
            )
            b.pack(fill="x", pady=4)

    def show_weather(self, place):
        self.clear()
        self.status.config(text="در حال دریافت وضعیت آب‌وهوا...")

        try:
            data = get_weather(place["latitude"], place["longitude"])
        except Exception as e:
            self.status.config(text="خطا")
            messagebox.showerror("خطا", f"دریافت آب‌وهوا انجام نشد.\n\n{e}")
            return

        self.status.config(text="")
        current = data.get("current", {})
        daily = data.get("daily", {})

        city = place.get("name", "")
        country = place.get("country", "")
        code = current.get("weather_code")
        desc = WEATHER_TEXT.get(code, "نامشخص")

        header = tk.Frame(self.result_frame, bg=self.card)
        header.pack(fill="x", pady=5)

        tk.Label(
            header, text=f"📍 {city}، {country}",
            font=("Segoe UI", 21, "bold"), bg=self.card, fg=self.text
        ).pack(pady=(18, 4))

        tk.Label(
            header, text=f"{desc}   •   {current.get('temperature_2m', '--')}°C",
            font=("Segoe UI", 19), bg=self.card, fg=self.accent
        ).pack(pady=4)

        info = (
            f"احساس واقعی: {current.get('apparent_temperature', '--')}°C    |    "
            f"رطوبت: {current.get('relative_humidity_2m', '--')}%    |    "
            f"باد: {current.get('wind_speed_10m', '--')} km/h"
        )
        tk.Label(
            header, text=info, font=("Segoe UI", 11),
            bg=self.card, fg=self.muted
        ).pack(pady=(3, 18))

        days = daily.get("time", [])
        forecast = tk.Frame(self.result_frame, bg=self.bg)
        forecast.pack(fill="both", expand=True, pady=10)

        tk.Label(
            forecast, text="پیش‌بینی ۷ روز آینده",
            font=("Segoe UI", 16, "bold"), bg=self.bg, fg=self.text
        ).pack(anchor="e", pady=(0, 8))

        for i, day in enumerate(days):
            code = daily.get("weather_code", [None]*len(days))[i]
            tmax = daily.get("temperature_2m_max", ["--"]*len(days))[i]
            tmin = daily.get("temperature_2m_min", ["--"]*len(days))[i]
            rain = daily.get("precipitation_probability_max", ["--"]*len(days))[i]
            wind = daily.get("wind_speed_10m_max", ["--"]*len(days))[i]

            row = tk.Frame(forecast, bg=self.card)
            row.pack(fill="x", pady=3)

            text = (
                f"{day}    |    {WEATHER_TEXT.get(code, 'نامشخص')}    |    "
                f"🌡 {tmin}° تا {tmax}°C    |    💧 احتمال بارش {rain}%    |    "
                f"💨 باد {wind} km/h"
            )
            tk.Label(
                row, text=text, font=("Segoe UI", 10),
                bg=self.card, fg=self.text, anchor="e"
            ).pack(fill="x", padx=12, pady=9)

        tk.Button(
            self.result_frame, text="← جستجوی شهر دیگر",
            command=self.search_again, font=("Segoe UI", 11, "bold"),
            bg="#263957", fg="white", relief="flat", cursor="hand2",
            padx=15, pady=8
        ).pack(pady=8)

    def search_again(self):
        self.clear()
        self.status.config(text="نام شهر را وارد کنید؛ مثلاً تهران، London یا Tokyo")
        self.city_entry.focus_set()

if __name__ == "__main__":
    root = tk.Tk()
    app = SmartWeather(root)
    root.mainloop()
